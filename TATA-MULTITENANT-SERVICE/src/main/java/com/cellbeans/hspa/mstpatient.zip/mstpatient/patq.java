package com.cellbeans.hspa.mstpatient;
//import com.mysema.query.types.expr.BooleanExpression;

public class patq {
    //static patq MstPatient = patq.MstPatient;
    //LocalDate today = new LocalDate();
    //BooleanExpression customerHasBirthday = customer.birthday.eq(today);
    //BooleanExpression isLongTermCustomer = customer.createdAt.lt(today.minusYears(2));
    //BooleanExpression customerHasBirthday = MstPatient.patientMrNo.eq("asas");
}
